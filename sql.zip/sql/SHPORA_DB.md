# 🎓 ГАЙД ПО БД: БИЛЕТ №1 (Книжный магазин)

---

## 📋 ЗАДАНИЕ 1: СОЗДАНИЕ ТАБЛИЦ (DDL)
**Что делать:** Скопируй код ниже, вставь в Workbench и нажми **первую молнию** ⚡️.
```sql
DROP DATABASE IF EXISTS bookshop;
CREATE DATABASE bookshop;
USE bookshop;

CREATE TABLE izdatelstva (id INT PRIMARY KEY AUTO_INCREMENT, n_izd VARCHAR(100) NOT NULL);
CREATE TABLE prodavcy (id INT PRIMARY KEY AUTO_INCREMENT, fio VARCHAR(100) NOT NULL, proc INT NOT NULL);
CREATE TABLE knigi (ISBN VARCHAR(20) PRIMARY KEY, id_izd INT NOT NULL, name VARCHAR(100) NOT NULL, author VARCHAR(100) NOT NULL, cena_zak INT NOT NULL, ost_sklad INT NOT NULL, cena_prod INT NOT NULL, FOREIGN KEY (id_izd) REFERENCES izdatelstva(id));
CREATE TABLE prodazhi (id INT PRIMARY KEY AUTO_INCREMENT, ISBN VARCHAR(20) NOT NULL, date_p DATE NOT NULL, qty INT NOT NULL, id_seller INT NOT NULL, FOREIGN KEY (ISBN) REFERENCES knigi(ISBN), FOREIGN KEY (id_seller) REFERENCES prodavcy(id));
```
**ЧТО ГОВОРИТЬ ПРЕПОДУ:** "Я спроектировал базу данных в 3-й нормальной форме. Установил связи 'Один-ко-многим' через Foreign Keys."

---

## 📥 ЗАДАНИЕ 2: ЗАПОЛНЕНИЕ ДАННЫМИ

### 1. ЗАПОЛНЕНИЕ (ИМПОРТ ИЛИ РУЧНОЙ ВВОД)

#### 🏢 ИЗДАТЕЛЬСТВА (izdatelstva)
1. ПКМ по таблице `izdatelstva` -> **Table Data Import Wizard**.
2. Выбери файл `TICKET1_PUBLISHERS.csv`.
3. **МАППИНГ:**
   - `id` -> `id`
   - `n_izd` -> `n_izd`
   - **ВАЖНО:** Если в правой колонке `Dest Column` стоит `(none)` — очисти это поле (выбери пустую строку).
4. Жми Next до конца.

*   **Ручной ввод (План Б):**
```sql
INSERT INTO izdatelstva (id, n_izd) VALUES (1, 'Eksmo'), (2, 'AST'), (3, 'Piter'), (4, 'Mann Ivanov');
```

#### 💼 ПРОДАВЦЫ (prodavcy)
1. ПКМ по таблице `prodavcy` -> **Table Data Import Wizard**.
2. Выбери файл `TICKET1_SELLERS.csv`.
3. **МАППИНГ:**
   - `id` -> `id`
   - `fio` -> `fio`
   - `proc` -> `proc`
   - **ВАЖНО:** Если в правой колонке `Dest Column` стоит `(none)` — очисти это поле (выбери пустую строку).
4. Жми Next до конца.

*   **Ручной ввод (План Б):**
```sql
INSERT INTO prodavcy (id, fio, proc) VALUES (1, 'Ivanov I.I.', 5), (2, 'Petrov P.P.', 7), (3, 'Sidorov S.S.', 6), (4, 'Kuznetsov A.A.', 8);
```

#### 📚 КНИГИ (knigi)
1. ПКМ по таблице `knigi` -> **Table Data Import Wizard**.
2. Выбери файл `EXAM_DATA_COMBINED.csv` (или `TICKET1_BOOKS.csv`).
3. **МАППИНГ:**
   - `ISBN` -> `ISBN`
   - `k_izd` -> `id_izd`
   - `n_book` -> `name`
   - `author` -> `author`
   - `cena_zak` -> `cena_zak`
   - `kol_sklad` -> `ost_sklad`
   - `cena_prod` -> `cena_prod`
   - **ВАЖНО:** Если в правой колонке `Dest Column` стоит `(none)` или что-то лишнее (например, kol_prod) — очисти это поле (выбери пустую строку).
4. Жми Next до конца.

#### 🛒 ПРОДАЖИ (prodazhi)
1. ПКМ по таблице `prodazhi` -> **Table Data Import Wizard**.
2. Выбери файл `EXAM_DATA_COMBINED.csv` (или `TICKET1_SALES.csv`).
3. **МАППИНГ:**
   - `ISBN` -> `ISBN`
   - `data_prod` -> `date_p`
   - `kol_prod` -> `qty`
   - `k_seller` -> `id_seller`
   - **ВАЖНО:** Если в правой колонке `Dest Column` стоит `(none)` или что-то лишнее (например, k_izd) — очисти это поле (выбери пустую строку).
4. Жми Next до конца.

---

## 📊 ЗАДАНИЕ 3: ЗАПРОС-ОТЧЕТ
```sql
SELECT p.date_p, k.name, (p.qty * k.cena_prod) AS total_price 
FROM prodazhi p JOIN knigi k ON p.ISBN = k.ISBN;
```
**ВИЗУАЛЬНОЕ ДОКАЗАТЕЛЬСТВО:** Покажи на колонку `total_price` и скажи: "Это вычисляемое поле: `Количество * Цена`."

---

## ⚡️ ЗАДАНИЕ 4: ТРИГГЕР (УЧЕТ СКЛАДА)
```sql
DELIMITER //
CREATE TRIGGER tr_stock BEFORE INSERT ON prodazhi FOR EACH ROW 
BEGIN 
  UPDATE knigi SET ost_sklad = ost_sklad - NEW.qty WHERE ISBN = NEW.ISBN; 
END //
DELIMITER ;

-- ПРОВЕРКА:
SELECT ost_sklad FROM knigi WHERE ISBN='978-5-01'; -- 1. Запомни цифру
INSERT INTO prodazhi (ISBN, date_p, qty, id_seller) VALUES ('978-5-01', CURDATE(), 1, 1);
SELECT ost_sklad FROM knigi WHERE ISBN='978-5-01'; -- 2. Покажи, что уменьшилась!
```

---

## 🛠 ЗАДАНИЕ 5: ВИЗУАЛИЗАЦИЯ И БЭКАП
1. **ER-диаграмма:** `Database` -> `Reverse Engineer`.
2. **Бэкап:** `Server` -> `Data Export`.

################################################################################

# 🎓 ГАЙД ПО БД: БИЛЕТ №2 (Поликлиника)

---

## 📋 ЗАДАНИЕ 1: СОЗДАНИЕ ТАБЛИЦ (DDL)
```sql
DROP DATABASE IF EXISTS polyclinic;
CREATE DATABASE polyclinic;
USE polyclinic;
CREATE TABLE patients (id INT PRIMARY KEY AUTO_INCREMENT, fio VARCHAR(100) NOT NULL, dr DATE NOT NULL, pol CHAR(1) NOT NULL);
CREATE TABLE doctors (id INT PRIMARY KEY AUTO_INCREMENT, fio VARCHAR(100) NOT NULL, spec VARCHAR(100) NOT NULL, kat VARCHAR(50) NOT NULL, tab_nom VARCHAR(20) NOT NULL);
CREATE TABLE services (id INT PRIMARY KEY AUTO_INCREMENT, n_usl VARCHAR(150) NOT NULL, stoim INT NOT NULL);
CREATE TABLE visits (id INT PRIMARY KEY AUTO_INCREMENT, id_pac INT NOT NULL, id_doc INT NOT NULL, id_usl INT NOT NULL, data_priem DATETIME NOT NULL, diag VARCHAR(255), lech TEXT, FOREIGN KEY (id_pac) REFERENCES patients(id), FOREIGN KEY (id_doc) REFERENCES doctors(id), FOREIGN KEY (id_usl) REFERENCES services(id));
```
**ЧТО ГОВОРИТЬ ПРЕПОДУ:** "Я спроектировал базу данных для поликлиники. Разделил врачей, пациентов и услуги на отдельные справочники и связал их в таблице приемов через Foreign Keys."
**ВИЗУАЛЬНОЕ ДОКАЗАТЕЛЬСТВО:** Меню `Database` -> `Reverse Engineer`. Покажи схему и скажи: "Связи настроены верно, зацикливаний нет."

---

## 📥 ЗАДАНИЕ 2: ЗАПОЛНЕНИЕ ДАННЫМИ

### 1. ЗАПОЛНЕНИЕ (ИМПОРТ ИЛИ РУЧНОЙ ВВОД)

#### 🩺 ВРАЧИ (doctors)
1. ПКМ по таблице `doctors` -> **Table Data Import Wizard**.
2. Выбери файл `TICKET2_DOCTORS.csv`.
3. **МАППИНГ:**
   - `id` -> `id`
   - `fio` -> `fio`
   - `spec` -> `spec`
   - `kat` -> `kat`
   - `tab_nom` -> `tab_nom`
   - **ВАЖНО:** Если в правой колонке `Dest Column` стоит `(none)` — очисти это поле (выбери пустую строку).
4. Жми Next до конца.

*   **Ручной ввод (План Б):**
```sql
INSERT INTO doctors (id, fio, spec, kat, tab_nom) VALUES (1, 'Ivanov I.I.', 'Therapist', 'Higher', 'T001'), (2, 'Petrov P.P.', 'Surgeon', 'First', 'T002'), (3, 'Sidorov S.S.', 'Oculist', 'Higher', 'T003'), (4, 'Kozlov A.A.', 'Neurologist', 'Second', 'T004'), (5, 'Smirnov B.V.', 'Dentist', 'Higher', 'T005'), (6, 'Popov K.M.', 'Therapist', 'First', 'T006');
```

#### 🤒 ПАЦИЕНТЫ (patients)
1. ПКМ по таблице `patients` -> **Table Data Import Wizard**.
2. Выбери файл `TICKET2_PATIENTS.csv`.
3. **МАППИНГ:**
   - `id` -> `id`
   - `fio` -> `fio`
   - `dr` -> `dr`
   - `pol` -> `pol`
   - **ВАЖНО:** Если в правой колонке `Dest Column` стоит `(none)` — очисти это поле (выбери пустую строку).
4. Жми Next до конца.

*   **Ручной ввод (План Б):**
```sql
INSERT INTO patients (id, fio, dr, pol) VALUES (1, 'Alice Smith', '1990-05-12', 'F'), (2, 'Bob Martin', '1985-03-22', 'M'), (3, 'Charlie Davis', '1995-11-30', 'M'), (4, 'Diana Lewis', '2000-01-15', 'F'), (5, 'Edward Norton', '1970-07-08', 'M'), (6, 'Fiona White', '1988-12-01', 'F'), (7, 'George Ross', '1992-04-14', 'M'), (8, 'Helen Brown', '1982-09-25', 'F'), (9, 'Ian Gray', '1998-02-11', 'M'), (10, 'Jane Kane', '2001-06-19', 'F'), (11, 'Kyle Thomas', '1975-10-05', 'M'), (12, 'Laura Moon', '1993-08-27', 'F'), (13, 'Mike Page', '1980-03-12', 'M'), (14, 'Nora Quinn', '1996-05-05', 'F'), (15, 'Oliver X.', '1984-11-11', 'M'), (16, 'Paula Z.', '1991-01-01', 'F'), (17, 'Quinn J.', '1978-02-28', 'M'), (18, 'Rose L.', '2002-10-10', 'F'), (19, 'Steve V.', '1987-07-07', 'M'), (20, 'Tina Fox', '1999-09-09', 'F');
```

#### 💊 УСЛУГИ (services)
1. ПКМ по таблице `services` -> **Table Data Import Wizard**.
2. Выбери файл `TICKET2_SERVICES.csv`.
3. **МАППИНГ:**
   - `id` -> `id`
   - `n_usl` -> `n_usl`
   - `stoim` -> `stoim`
   - **ВАЖНО:** Если в правой колонке `Dest Column` стоит `(none)` — очисти это поле (выбери пустую строку).
4. Жми Next до конца.

*   **Ручной ввод (План Б):**
```sql
INSERT INTO services (id, n_usl, stoim) VALUES (1, 'Consultation', 1000), (2, 'Blood Test', 500), (3, 'X-Ray', 1500), (4, 'MRI', 5000), (5, 'Urine Test', 300), (6, 'ECG', 800), (7, 'Massage', 1200), (8, 'Injection', 200), (9, 'Ultrasound', 2000), (10, 'Operation', 15000), (11, 'Check-up', 0);
```

### 2. ИМПОРТ (ПРИЕМЫ)
1. ПКМ по таблице `visits` -> **Table Data Import Wizard**.
2. Выбери файл `TICKET2_DATA.csv`.
3. **МАППИНГ:**
   - `k_pac` -> `id_pac`
   - `k_doc` -> `id_doc`
   - `k_usl` -> `id_usl`
   - `data_priem` -> `data_priem`
   - `diag` -> `diag`
   - `lech` -> `lech`
   - **ВАЖНО:** Если в правой колонке `Dest Column` стоит `(none)` или что-то лишнее — очисти это поле (выбери пустую строку).
4. Жми Next до конца.

### 3. ПЛАН "Б" (ЕСЛИ ИМПОРТ НЕ СРАБОТАЛ)
**Что делать:** Если мастер импорта выдает ошибки, просто запусти этот код. Тут 31 запись (норма для экзамена).
```sql
USE polyclinic;
INSERT INTO visits (id_pac, id_doc, id_usl, data_priem, diag, lech) VALUES 
(1,1,1,'2024-01-10 09:00:00','Flu','Rest'), (2,2,2,'2024-01-10 10:00:00','Fracture','Cast'), (3,3,3,'2024-01-11 11:00:00','Myopia','Glasses'),
(4,4,4,'2024-01-11 12:00:00','Headache','MRI'), (5,5,5,'2024-01-12 13:00:00','Cavity','Filling'), (6,6,6,'2024-01-12 14:00:00','Arrhythmia','ECG'),
(7,1,7,'2024-01-13 09:30:00','Back pain','Massage'), (8,2,8,'2024-01-13 10:30:00','Infection','Pills'), (9,3,9,'2024-01-14 11:30:00','Stomach','Ultrasound'),
(10,4,10,'2024-01-14 12:30:00','Appendic','Surgery'), (11,5,11,'2024-01-15 13:30:00','Check','Ok'), (12,6,1,'2024-01-15 14:30:00','Cough','Syrup'),
(13,1,2,'2024-01-16 09:00:00','Anemia','Iron'), (14,2,3,'2024-01-16 10:00:00','Vision','Drops'), (15,3,4,'2024-01-17 11:00:00','Dizzy','Check'),
(16,4,5,'2024-01-17 12:00:00','Allergy','Antihist'), (17,5,6,'2024-01-18 13:00:00','Hypertens','Pills'), (18,6,7,'2024-01-18 14:00:00','Strain','Rest'),
(19,1,8,'2024-01-19 09:30:00','Throat','Gargle'), (20,2,9,'2024-01-19 10:30:00','Gastritis','Diet'), (1,3,10,'2024-01-20 11:30:00','Cataract','Surgery'),
(2,4,1,'2024-01-20 12:30:00','Migraine','Sleep'), (3,5,2,'2024-01-21 13:30:00','Diabetes','Insulin'), (4,6,3,'2024-01-21 14:30:00','Glaucoma','Test'),
(5,1,4,'2024-01-22 09:00:00','Back','Physio'), (6,2,5,'2024-01-22 10:00:00','Rash','Ointment'), (7,3,6,'2024-01-23 11:00:00','Chest','ECG'),
(8,4,7,'2024-01-23 12:00:00','Stress','Relax'), (9,5,8,'2024-01-24 13:00:00','Cold','Tea'), (10,6,9,'2024-01-24 14:00:00','Indigest','Enzymes'),
(11,1,10,'2024-01-25 09:30:00','Hernia','Ops');
```

**КАК ПРОВЕРИТЬ (ПОКАЗАТЬ ПРЕПОДУ):**
```sql
SELECT COUNT(*) FROM patients; -- Должно быть 20+
SELECT COUNT(*) FROM visits;   -- Должно быть 30+
```

---

## 📊 ЗАДАНИЕ 3: ЗАПРОСЫ
**1. Пациенты у врача за период:**
```sql
SELECT p.fio, v.data_priem FROM visits v JOIN patients p ON v.id_pac = p.id WHERE v.id_doc = 1;
```
**2. Врачи со стоимостью выше средней:**
```sql
SELECT d.fio, AVG(s.stoim) as avg_s FROM visits v JOIN doctors d ON v.id_doc = d.id JOIN services s ON v.id_usl = s.id GROUP BY d.id HAVING avg_s > (SELECT AVG(stoim) FROM services);
```
**3. Неиспользованные услуги:**
```sql
SELECT n_usl FROM services WHERE id NOT IN (SELECT DISTINCT id_usl FROM visits);
```
UPDATE services s JOIN visits v ON s.id = v.id_usl JOIN doctors d ON v.id_doc = d.id SET s.stoim = s.stoim * 1.05 WHERE d.kat = 'Higher';
```
**ВИЗУАЛЬНОЕ ДОКАЗАТЕЛЬСТВО (ПО ЗАПРОСАМ):**
1. **Запрос 1:** "Показываю пациентов конкретного врача: данные отфильтрованы по ID врача."
2. **Запрос 2:** "Тут я использовал подзапрос для расчета средней стоимости по всей базе и сравнил её с врачами через `HAVING`."
3. **Запрос 3:** "Этот запрос находит 'мертвые' услуги, которые заведены, но еще ни разу не оказывались."
4. **Запрос 4:** "Я обновил данные сразу в двух таблицах через `JOIN`, увеличив цену услуг только для опытных врачей."

---

## ⚡️ ЗАДАНИЕ 4: ТРИГГЕР (ПРОВЕРКА ВРЕМЕНИ)
```sql
DELIMITER //
CREATE TRIGGER tr_visit BEFORE INSERT ON visits FOR EACH ROW 
BEGIN 
  IF EXISTS (SELECT 1 FROM visits WHERE id_pac = NEW.id_pac AND data_priem = NEW.data_priem) THEN 
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Double booking!'; 
  END IF; 
END //
DELIMITER ;
```
**ВИЗУАЛЬНОЕ ДОКАЗАТЕЛЬСТВО (ДЛЯ ПРЕПОДА):**
**ВИЗУАЛЬНОЕ ДОКАЗАТЕЛЬСТВО (ДЛЯ ПРЕПОДА):**
1. Скажи: "Сейчас я попробую записать пациента на одно и то же время к двум разным врачам."
2. Запусти первый `INSERT`.
3. Запусти второй `INSERT` на то же время.
4. Укажи на красное сообщение об ошибке внизу и скажи: "База заблокировала вставку, так как сработал мой триггер `tr_visit`."

---

## 🛠 ЗАДАНИЕ 5: БЭКАП (Как в Билете 1)

---
---

# 🎓 ГАЙД ПО БД: БИЛЕТ №3 (Автопредприятие)

---

## 📋 ЗАДАНИЕ 1: СОЗДАНИЕ ТАБЛИЦ (DDL)
```sql
DROP DATABASE IF EXISTS auto_ent;
CREATE DATABASE auto_ent;
USE auto_ent;

CREATE TABLE cars (id INT PRIMARY KEY AUTO_INCREMENT, gosnom VARCHAR(15) NOT NULL, marka VARCHAR(50) NOT NULL, god INT NOT NULL, req_cat CHAR(1) NOT NULL);
CREATE TABLE drivers (id INT PRIMARY KEY AUTO_INCREMENT, fio VARCHAR(100) NOT NULL, kat_prav VARCHAR(10) NOT NULL, oklad INT NOT NULL, stag INT NOT NULL);
CREATE TABLE trips (id INT PRIMARY KEY AUTO_INCREMENT, id_avto INT NOT NULL, id_vod INT NOT NULL, k_reis VARCHAR(20) NOT NULL, punkt VARCHAR(100) NOT NULL, data_reis DATE NOT NULL, probeg INT NOT NULL, rashod INT NOT NULL, stoim_perev INT NOT NULL, procent_vod INT NOT NULL, FOREIGN KEY (id_avto) REFERENCES cars(id), FOREIGN KEY (id_vod) REFERENCES drivers(id));
```
**ЧТО ГОВОРИТЬ ПРЕПОДУ:** "Я спроектировал систему учета рейсов. Главная таблица `trips` связывает автомобили и водителей. Реализована каскадная целостность данных через внешние ключи."
**ВИЗУАЛЬНОЕ ДОКАЗАТЕЛЬСТВО:** `Database` -> `Reverse Engineer`. Покажи связи и скажи: "Схема нормализована, избыточность данных сведена к минимуму."

---

## 📥 ЗАДАНИЕ 2: ЗАПОЛНЕНИЕ ДАННЫМИ

### 1. ЗАПОЛНЕНИЕ (ИМПОРТ ИЛИ РУЧНОЙ ВВОД)

#### 🚛 МАШИНЫ (cars)
1. ПКМ по таблице `cars` -> **Table Data Import Wizard**.
2. Выбери файл `TICKET3_CARS.csv`.
3. **МАППИНГ:**
   - `id` -> `id`
   - `gosnom` -> `gosnom`
   - `marka` -> `marka`
   - `god` -> `god`
   - `req_cat` -> `req_cat`
   - **ВАЖНО:** Если в правой колонке `Dest Column` стоит `(none)` — очисти это поле (выбери пустую строку).
4. Жми Next до конца.

*   **Ручной ввод (План Б):**
```sql
INSERT INTO cars (id, gosnom, marka, god, req_cat) VALUES (1, 'A001AA', 'KAMAZ', 2020, 'C'), (2, 'B002BB', 'GAZEL', 2018, 'B'), (3, 'C003CC', 'SCANIA', 2021, 'C'), (4, 'D004DD', 'RENAULT', 2019, 'B'), (5, 'E005EE', 'MAN', 2022, 'C');
```

#### 👨‍✈️ ВОДИТЕЛИ (drivers)
1. ПКМ по таблице `drivers` -> **Table Data Import Wizard**.
2. Выбери файл `TICKET3_DRIVERS.csv`.
3. **МАППИНГ:**
   - `id` -> `id`
   - `fio` -> `fio`
   - `kat_prav` -> `kat_prav`
   - `oklad` -> `oklad`
   - `stag` -> `stag`
   - **ВАЖНО:** Если в правой колонке `Dest Column` стоит `(none)` — очисти это поле (выбери пустую строку).
4. Жми Next до конца.

*   **Ручной ввод (План Б):**
```sql
INSERT INTO drivers (id, fio, kat_prav, oklad, stag) VALUES (1, 'Ivanov I.I.', 'BC', 40000, 12), (2, 'Petrov P.P.', 'B', 30000, 5), (3, 'Sidorov S.S.', 'C', 45000, 15), (4, 'Kozlov A.A.', 'B', 32000, 8), (5, 'Smirnov B.V.', 'BC', 42000, 11), (6, 'Popov K.M.', 'C', 44000, 3), (7, 'Vasiliev V.V.', 'B', 31000, 6);
```

### 2. ИМПОРТ (РЕЙСЫ)
1. ПКМ по таблице `trips` -> **Table Data Import Wizard**.
2. Выбери файл `TICKET3_DATA.csv`.
3. **МАППИНГ:**
   - `k_avto` -> `id_avto`
   - `k_vod` -> `id_vod`
   - `k_reis` -> `k_reis`
   - `punkt` -> `punkt`
   - `data_reis` -> `data_reis`
   - `probeg` -> `probeg`
   - `rashod` -> `rashod`
   - `stoim_perev` -> `stoim_perev`
   - `procent_vod` -> `procent_vod`
   - **ВАЖНО:** Если в правой колонке `Dest Column` стоит `(none)` или что-то лишнее — очисти это поле (выбери пустую строку).
4. Жми Next до конца.

### 3. ПЛАН "Б" (РУЧНОЙ ВВОД)
**Что делать:** Если импорт не идет, используй этот код. Тут 27 рейсов.
```sql
USE auto_ent;
INSERT INTO trips (id_avto, id_vod, k_reis, punkt, data_reis, probeg, rashod, stoim_perev, procent_vod) VALUES 
(1,1,'R001','Moscow','2024-11-01',500,100,50000,10), (2,2,'R002','Kazan','2024-11-02',800,120,80000,8), (3,3,'R003','Sochi','2024-11-03',1500,300,150000,12),
(4,4,'R004','Pskov','2024-11-04',300,50,30000,5), (5,5,'R005','Tver','2024-11-05',200,40,20000,5), (1,6,'R006','Samara','2024-11-06',1000,200,100000,10),
(2,7,'R007','Ufa','2024-11-07',1200,180,120000,9), (3,1,'R008','Moscow','2024-11-08',1500,300,150000,11), (4,2,'R009','Kazan','2024-11-09',800,120,80000,7),
(5,3,'R010','Sochi','2024-11-10',1500,300,150000,12), (1,4,'R011','Pskov','2024-11-11',300,50,30000,6), (2,5,'R012','Tver','2024-11-12',200,40,20000,5),
(3,6,'R013','Samara','2024-11-13',1000,200,100000,10), (4,7,'R014','Ufa','2024-11-14',1200,180,120000,8), (5,1,'R015','Moscow','2024-11-15',500,100,50000,10),
(1,2,'R016','Kazan','2024-11-16',800,120,80000,8), (2,3,'R017','Sochi','2024-11-17',1500,300,150000,12), (3,4,'R018','Pskov','2024-11-18',300,50,30000,5),
(4,5,'R019','Tver','2024-11-19',200,40,20000,5), (5,6,'R020','Samara','2024-11-20',1000,200,100000,10), (1,7,'R021','Ufa','2024-11-21',1200,180,120000,9),
(2,1,'R022','Moscow','2024-11-22',1500,300,150000,11), (3,2,'R023','Kazan','2024-11-23',800,120,80000,7), (4,3,'R024','Sochi','2024-11-24',1500,300,150000,12),
(5,4,'R025','Pskov','2024-11-25',300,50,30000,6), (1,5,'R026','Tver','2024-11-26',200,40,20000,5), (2,6,'R027','Samara','2024-11-27',1000,200,100000,10);
```

**КАК ПРОВЕРИТЬ (ПОКАЗАТЬ ПРЕПОДУ):**
```sql
SELECT COUNT(*) FROM drivers; -- Должно быть 7+
SELECT COUNT(*) FROM trips;   -- Должно быть 25+
```

---

## 📊 ЗАДАНИЕ 3: ЗАПРОСЫ
**1. Отчет за месяц:**
```sql
SELECT t.data_reis, c.marka, c.gosnom, d.fio, t.punkt, t.probeg, t.stoim_perev as income FROM trips t JOIN cars c ON t.id_avto = c.id JOIN drivers d ON t.id_vod = d.id WHERE MONTH(t.data_reis) = 11;
```
**2. Водители с комиссией выше среднего:**
```sql
SELECT d.fio, SUM(t.stoim_perev * t.procent_vod / 100) as total_comm FROM trips t JOIN drivers d ON t.id_vod = d.id GROUP BY d.id HAVING total_comm > (SELECT AVG(comm) FROM (SELECT SUM(stoim_perev * procent_vod / 100) as comm FROM trips GROUP BY id_vod) as sub);
```
**3. Автомобили без рейсов в этом месяце:**
```sql
SELECT marka, gosnom FROM cars WHERE id NOT IN (SELECT id_avto FROM trips WHERE MONTH(data_reis) = MONTH(CURDATE()));
```
**4. Увеличить оклад на 10% (Стаж > 10 лет):**
```sql
UPDATE drivers SET oklad = oklad * 1.1 WHERE stag > 10;
```
**ВИЗУАЛЬНОЕ ДОКАЗАТЕЛЬСТВО (ПО ЗАПРОСАМ):**
1. **Запрос 1:** "Это отчет за месяц. Я объединил 3 таблицы через `JOIN`, чтобы вывести и ФИО водителя, и марку машины в одной строке."
2. **Запрос 2:** "Сложный расчет комиссий с фильтрацией `HAVING`. Показывает только самых эффективных водителей."
3. **Запрос 3:** "Этот запрос находит 'простаивающие' автомобили, по которым нет записей в текущем месяце."
4. **Запрос 4:** "Автоматическое повышение оклада — я обновил данные только тем, у кого стаж в поле `stag` больше 10 лет."

---

## ⚡️ ЗАДАНИЕ 4: ТРИГГЕР (КАТЕГОРИЯ ПРАВ)
```sql
DELIMITER //
CREATE TRIGGER tr_check_cat BEFORE INSERT ON trips FOR EACH ROW 
BEGIN 
  DECLARE d_cat VARCHAR(10); DECLARE c_cat CHAR(1);
  SELECT kat_prav INTO d_cat FROM drivers WHERE id = NEW.id_vod;
  SELECT req_cat INTO c_cat FROM cars WHERE id = NEW.id_avto;
  IF d_cat NOT LIKE CONCAT('%', c_cat, '%') THEN 
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Driver lacks required license category!'; 
  END IF; 
END //
DELIMITER ;
```
**ВИЗУАЛЬНОЕ ДОКАЗАТЕЛЬСТВО (ДЛЯ ПРЕПОДА):**
1. Скажи: "У водителя №2 (Petrov) права категории B. Сейчас я попробую назначить его на КАМАЗ (ID 1), которому нужна категория C."
2. Попробуй вставить: `INSERT INTO trips (id_avto, id_vod, k_reis, punkt, data_reis, probeg, rashod, stoim_perev, procent_vod) VALUES (1, 2, 'R001', 'Moscow', '2024-12-27', 500, 100, 10000, 5);`
3. Покажи на ошибку: "Система выдала `Driver lacks required license category!`, значит триггер работает корректно."

## 🛠 ЗАДАНИЕ 5: БЭКАП (Как в Билете 1)

---
---

# 🎓 ГАЙД ПО БД: БИЛЕТ №4 (Образовательный центр)

---

## 📋 ЗАДАНИЕ 1: СОЗДАНИЕ ТАБЛИЦ (DDL)
```sql
DROP DATABASE IF EXISTS edu_center;
CREATE DATABASE edu_center;
USE edu_center;

CREATE TABLE teachers (id INT PRIMARY KEY AUTO_INCREMENT, fio VARCHAR(100) NOT NULL, stavka INT NOT NULL);
CREATE TABLE courses (id INT PRIMARY KEY AUTO_INCREMENT, n_kurs VARCHAR(100) NOT NULL, id_prep INT NOT NULL, stoim_kurs INT NOT NULL, chasy INT NOT NULL, FOREIGN KEY (id_prep) REFERENCES teachers(id));
CREATE TABLE students (id INT PRIMARY KEY AUTO_INCREMENT, fio VARCHAR(100) NOT NULL, phone VARCHAR(20));
CREATE TABLE attendance (id INT PRIMARY KEY AUTO_INCREMENT, id_stud INT NOT NULL, id_kurs INT NOT NULL, data_pos DATE NOT NULL, status ENUM('present', 'absent') NOT NULL, ocenka FLOAT, FOREIGN KEY (id_stud) REFERENCES students(id), FOREIGN KEY (id_kurs) REFERENCES courses(id));

CREATE TABLE salary (id INT PRIMARY KEY AUTO_INCREMENT, id_prep INT NOT NULL, amount INT NOT NULL, date_calc DATE NOT NULL);
```
**ЧТО ГОВОРИТЬ ПРЕПОДУ:** "Я спроектировал базу данных для учебного центра. Сущности 'Преподаватели' и 'Курсы' связаны отношением 'один-ко-многим', а посещаемость фиксирует взаимодействие студентов с курсами."
**ВИЗУАЛЬНОЕ ДОКАЗАТЕЛЬСТВО:** `Database` -> `Reverse Engineer`. Покажи схему и скажи: "База нормализована, структура позволяет отслеживать успеваемость и финансы."

---

## 📥 ЗАДАНИЕ 2: ЗАПОЛНЕНИЕ ДАННЫМИ

### 1. ЗАПОЛНЕНИЕ (ИМПОРТ ИЛИ РУЧНОЙ ВВОД)

#### 🏫 ПРЕПОДАВАТЕЛИ (teachers)
1. ПКМ по таблице `teachers` -> **Table Data Import Wizard**.
2. Выбери файл `TICKET4_TEACHERS.csv`.
3. **МАППИНГ:**
   - `id` -> `id`
   - `fio` -> `fio`
   - `stavka` -> `stavka`
   - **ВАЖНО:** Если в правой колонке `Dest Column` стоит `(none)` — очисти это поле (выбери пустую строку).
4. Жми Next до конца.

*   **Ручной ввод (План Б):**
```sql
INSERT INTO teachers (id, fio, stavka) VALUES (1, 'Sidorov P.S.', 500), (2, 'Ivanov A.A.', 600), (3, 'Petrov B.B.', 550), (4, 'Smirnov D.D.', 700), (5, 'Popov E.E.', 450);
```

#### 📚 КУРСЫ (courses)
1. ПКМ по таблице `courses` -> **Table Data Import Wizard**.
2. Выбери файл `TICKET4_COURSES.csv`.
3. **МАППИНГ:**
   - `id` -> `id`
   - `n_kurs` -> `n_kurs`
   - `id_prep` -> `id_prep`
   - `stoim_kurs` -> `stoim_kurs`
   - `chasy` -> `chasy`
   - **ВАЖНО:** Если в правой колонке `Dest Column` стоит `(none)` — очисти это поле (выбери пустую строку).
4. Жми Next до конца.

*   **Ручной ввод (План Б):**
```sql
INSERT INTO courses (id, n_kurs, id_prep, stoim_kurs, chasy) VALUES (1, 'SQL Basic', 1, 10000, 40), (2, 'Python Pro', 2, 20000, 60), (3, 'Web Design', 3, 15000, 30), (4, 'Java Dev', 4, 25000, 80), (5, 'C++ Expert', 2, 30000, 100), (6, 'Excel for Pros', 1, 5000, 20), (7, 'Docker', 5, 12000, 24), (8, 'Testing QA', 3, 14000, 40);
```

#### 🎓 СТУДЕНТЫ (students)
1. ПКМ по таблице `students` -> **Table Data Import Wizard**.
2. Выбери файл `TICKET4_STUDENTS.csv`.
3. **МАППИНГ:**
   - `id` -> `id`
   - `fio` -> `fio`
   - `phone` -> `phone`
   - **ВАЖНО:** Если в правой колонке `Dest Column` стоит `(none)` — очисти это поле (выбери пустую строку).
4. Жми Next до конца.

*   **Ручной ввод (План Б):**
```sql
INSERT INTO students (id, fio, phone) VALUES (1, 'John Doe', '555-0101'), (2, 'Jane Doe', '555-0102'), (3, 'Jim Beam', '555-0103'), (4, 'Jack Daniels', '555-0104'), (5, 'Johnny Walker', '555-0105'), (6, 'Bill Gates', '555-0106'), (7, 'Steve Jobs', '555-0107'), (8, 'Elon Musk', '555-0108'), (9, Mark Zuckerberg', '555-0109'), (10, 'Larry Page', '555-0110'), (11, 'Sergey Brin', '555-0111'), (12, 'Jeff Bezos', '555-0112'), (13, 'Tim Cook', '555-0113'), (14, 'Satya Nadella', '555-0114'), (15, 'Sundar Pichai', '555-0115'), (16, 'Reed Hastings', '555-0116'), (17, 'Marc Benioff', '555-0117'), (18, 'Jensen Huang', '555-0118'), (19, 'Lisa Su', '555-0119'), (20, 'Gabe Newell', '555-0120'), (21, 'Peter Thiel', '555-0121'), (22, 'Max Levchin', '555-0122'), (23, 'Roelof Botha', '555-0123'), (24, 'Keith Rabois', '555-0124'), (25, 'David Sacks', '555-0125');
```

### 2. ИМПОРТ (ПОСЕЩЕНИЯ)
1. ПКМ по таблице `attendance` -> **Table Data Import Wizard**.
2. Выбери файл `TICKET4_DATA.csv`.
3. **МАППИНГ:**
   - `k_stud` -> `id_stud`
   - `k_kurs` -> `id_kurs`
   - `data_pos` -> `data_pos`
   - `status` -> `status`
   - `ocenka` -> `ocenka`
   - **ВАЖНО:** Если в правой колонке `Dest Column` стоит `(none)` или что-то лишнее — очисти это поле (выбери пустую строку).
4. Жми Next до конца.

### 3. ПЛАН "Б" (РУЧНОЙ ВВОД)
**Что делать:** Если импорт не сработал. Тут 40 записей.
```sql
USE edu_center;
INSERT INTO attendance (id_stud, id_kurs, data_pos, status, ocenka) VALUES 
(1,1,'2024-09-01','present',4.5), (2,1,'2024-09-01','present',3.0), (3,1,'2024-09-01','absent',NULL), (4,2,'2024-09-02','present',5.0),
(5,2,'2024-09-02','present',4.8), (6,3,'2024-09-03','present',4.2), (7,4,'2024-09-04','present',3.5), (8,5,'2024-09-05','present',5.0),
(9,6,'2024-09-06','absent',NULL), (10,7,'2024-09-07','present',4.0), (11,8,'2024-09-08','present',4.9), (12,1,'2024-09-09','present',3.8),
(13,2,'2024-09-10','present',4.7), (14,3,'2024-09-11','present',3.2), (15,4,'2024-09-12','present',4.1), (16,5,'2024-09-13','absent',NULL),
(17,6,'2024-09-14','present',4.4), (18,7,'2024-09-15','present',4.6), (19,8,'2024-09-16','present',3.9), (20,1,'2024-09-17','present',5.0),
(21,2,'2024-09-18','present',4.3), (22,3,'2024-09-19','absent',NULL), (23,4,'2024-09-20','present',4.8), (24,5,'2024-09-21','present',3.7),
(25,6,'2024-09-22','present',4.5), (1,7,'2024-09-23','present',4.2), (2,8,'2024-09-24','present',4.0), (3,1,'2024-09-25','absent',NULL),
(4,2,'2024-09-26','present',5.0), (5,3,'2024-09-27','present',4.9), (6,4,'2024-09-28','present',3.5), (7,5,'2024-09-29','present',4.1),
(8,6,'2024-09-30','present',4.3), (9,7,'2024-10-01','absent',NULL), (10,8,'2024-10-02','present',4.7), (11,1,'2024-10-03','present',4.4),
(12,2,'2024-10-04','present',3.8), (13,3,'2024-10-05','present',4.9), (14,4,'2024-10-06','present',4.5), (15,5,'2024-10-07','absent',NULL);
```

**КАК ПРОВЕРИТЬ (ПОКАЗАТЬ ПРЕПОДУ):**
```sql
SELECT COUNT(*) FROM students;   -- Должно быть 25+
SELECT COUNT(*) FROM attendance; -- Должно быть 100+
```

---

## 📊 ЗАДАНИЕ 3: ЗАПРОСЫ
**1. Посещаемость студента:**
```sql
SELECT data_pos, status FROM attendance WHERE id_stud = 1 AND id_kurs = 1;
```
**2. Курсы дороже среднего:**
```sql
SELECT n_kurs, stoim_kurs FROM courses WHERE stoim_kurs > (SELECT AVG(stoim_kurs) FROM courses);
```
**3. Студенты-прогульщики:**
```sql
SELECT fio FROM students WHERE id NOT IN (SELECT DISTINCT id_stud FROM attendance WHERE status = 'present');
```
**4. Поднять ставку на 7% (Балл > 4.5):**
```sql
UPDATE teachers t SET stavka = stavka * 1.07 WHERE t.id IN (SELECT c.id_prep FROM courses c JOIN attendance a ON c.id = a.id_kurs GROUP BY c.id_prep HAVING AVG(a.ocenka) > 4.5);
```
**ВИЗУАЛЬНОЕ ДОКАЗАТЕЛЬСТВО (ПО ЗАПРОСАМ):**
1. **Запрос 1:** "Детальный отчет по одному студенту. Удобно для проверки журнала посещаемости."
2. **Запрос 2:** "Аналитика стоимости курсов. Использую подзапрос для сравнения конкретных курсов со средним рыночным значением."
3. **Запрос 3:** "Поиск 'мертвых душ' — студентов, которые записаны, но ни разу не пришли."
4. **Запрос 4:** "Мотивационная система: ставка преподавателя растет автоматически, если его ученики в среднем получают выше 4.5."

---

## ⚡️ ЗАДАНИЕ 4: ТРИГГЕР (ЗАРПЛАТА)
```sql
DELIMITER //
CREATE TRIGGER tr_salary AFTER INSERT ON attendance FOR EACH ROW 
BEGIN 
  DECLARE t_id, t_stavka, t_hours INT;
  SELECT id_prep, chasy INTO t_id, t_hours FROM courses WHERE id = NEW.id_kurs;
  SELECT stavka INTO t_stavka FROM teachers WHERE id = t_id;
  INSERT INTO salary (id_prep, amount, date_calc) VALUES (t_id, t_stavka * t_hours, CURDATE());
END //
DELIMITER ;

**ВИЗУАЛЬНОЕ ДОКАЗАТЕЛЬСТВО (ДЛЯ ПРЕПОДА):**
1. Скажи: "Сейчас я зафиксирую посещение студентом занятия, и система сама начислит зарплату учителю."
2. Проверь пустую таблицу: `SELECT * FROM salary;`
3. Вставь запись: `INSERT INTO attendance (id_stud, id_kurs, data_pos, status, ocenka) VALUES (1, 1, '2024-12-27', 'present', 5);`
4. Покажи новую строку в зарплате: `SELECT * FROM salary;` — "Сумма рассчиталась автоматически как `Ставка * Часы курса`."
```

---

## 🛠 ЗАДАНИЕ 5: БЭКАП (Как в Билете 1)

---
---

# 🎓 ГАЙД ПО БД: БИЛЕТ №5 (Стройматериалы)

---

## 📋 ЗАДАНИЕ 1: СОЗДАНИЕ ТАБЛИЦ (DDL)
```sql
DROP DATABASE IF EXISTS build_mat;
CREATE DATABASE build_mat;
USE build_mat;

CREATE TABLE suppliers (id INT PRIMARY KEY AUTO_INCREMENT, n_post VARCHAR(100) NOT NULL);
CREATE TABLE clients (id INT PRIMARY KEY AUTO_INCREMENT, n_klient VARCHAR(100) NOT NULL);
CREATE TABLE managers (id INT PRIMARY KEY AUTO_INCREMENT, fio_man VARCHAR(100) NOT NULL, procent INT NOT NULL);
CREATE TABLE materials (id INT PRIMARY KEY AUTO_INCREMENT, n_mat VARCHAR(100) NOT NULL, ed_izm VARCHAR(10) NOT NULL, cena_post INT NOT NULL, kol_sklad INT NOT NULL, min_reserve INT NOT NULL, cena_otgr INT NOT NULL, id_post INT NOT NULL, reserve INT DEFAULT 0, FOREIGN KEY (id_post) REFERENCES suppliers(id));
CREATE TABLE shipments (id INT PRIMARY KEY AUTO_INCREMENT, id_mat INT NOT NULL, id_klient INT NOT NULL, id_man INT NOT NULL, data_otgr DATE NOT NULL, v_otgr INT NOT NULL, FOREIGN KEY (id_mat) REFERENCES materials(id), FOREIGN KEY (id_klient) REFERENCES clients(id), FOREIGN KEY (id_man) REFERENCES managers(id));
CREATE TABLE purchase_requests (id INT PRIMARY KEY AUTO_INCREMENT, id_mat INT NOT NULL, qty INT NOT NULL, date_req DATE NOT NULL);
```
**ЧТО ГОВОРИТЬ ПРЕПОДУ:** "Это сложная база складского учета. Я реализовал контроль остатков, резервирование товара и автоматическое формирование заявок на закупку через триггеры."
**ВИЗУАЛЬНОЕ ДОКАЗАТЕЛЬСТВО:** `Database` -> `Reverse Engineer`. Покажи связи и скажи: "Схема поддерживает полную цепочку от поставки до отгрузки клиенту."

---

## 📥 ЗАДАНИЕ 2: ЗАПОЛНЕНИЕ ДАННЫМИ

### 1. ЗАПОЛНЕНИЕ (ИМПОРТ ИЛИ РУЧНОЙ ВВОД)

#### 📦 ПОСТАВЩИКИ (suppliers)
1. ПКМ по таблице `suppliers` -> **Table Data Import Wizard**.
2. Выбери файл `TICKET5_SUPPLIERS.csv`.
3. **МАППИНГ:**
   - `id` -> `id`
   - `n_post` -> `n_post`
   - **ВАЖНО:** Если в правой колонке `Dest Column` стоит `(none)` — очисти это поле (выбери пустую строку).
4. Жми Next до конца.

*   **Ручной ввод (План Б):**
```sql
INSERT INTO suppliers (id, n_post) VALUES (1, 'StroyOpt'), (2, 'MegaMat'), (3, 'StroyBase'), (4, 'GlobalBuild');
```

#### 🤝 КЛИЕНТЫ (clients)
1. ПКМ по таблице `clients` -> **Table Data Import Wizard**.
2. Выбери файл `TICKET5_CLIENTS.csv`.
3. **МАППИНГ:**
   - `id` -> `id`
   - `n_klient` -> `n_klient`
   - **ВАЖНО:** Если в правой колонке `Dest Column` стоит `(none)` — очисти это поле (выбери пустую строку).
4. Жми Next до конца.

*   **Ручной ввод (План Б):**
```sql
INSERT INTO clients (id, n_klient) VALUES (1, 'OOO Dom'), (2, 'IP Build'), (3, 'City Stroy'), (4, 'Eco Build'), (5, 'Renovation Co'), (6, 'Elite Design');
```

#### 💼 МЕНЕДЖЕРЫ (managers)
1. ПКМ по таблице `managers` -> **Table Data Import Wizard**.
2. Выбери файл `TICKET5_MANAGERS.csv`.
3. **МАППИНГ:**
   - `id` -> `id`
   - `fio_man` -> `fio_man`
   - `procent` -> `procent`
   - **ВАЖНО:** Если в правой колонке `Dest Column` стоит `(none)` — очисти это поле (выбери пустую строку).
4. Жми Next до конца.

*   **Ручной ввод (План Б):**
```sql
INSERT INTO managers (id, fio_man, procent) VALUES (1, 'Ivanov I.I.', 5), (2, 'Petrov P.P.', 3), (3, 'Sidorov S.S.', 4);
```

#### 🧱 МАТЕРИАЛЫ (materials)
1. ПКМ по таблице `materials` -> **Table Data Import Wizard**.
2. Выбери файл `TICKET5_MATERIALS.csv`.
3. **МАППИНГ:**
   - `id` -> `id`
   - `n_mat` -> `n_mat`
   - `ed_izm` -> `ed_izm`
   - `cena_post` -> `cena_post`
   - `kol_sklad` -> `kol_sklad`
   - `min_reserve` -> `min_reserve`
   - `cena_otgr` -> `cena_otgr`
   - `id_post` -> `id_post`
   - **ВАЖНО:** Если в правой колонке `Dest Column` стоит `(none)` — очисти это поле (выбери пустую строку).
4. Жми Next до конца.

*   **Ручной ввод (План Б):**
```sql
INSERT INTO materials (id, n_mat, ed_izm, cena_post, kol_sklad, min_reserve, cena_otgr, id_post) VALUES (1, 'Cement', 'bag', 300, 100, 20, 360, 1), (2, 'Brick', 'pcs', 15, 5000, 500, 18, 2), (3, 'Sand', 'ton', 500, 50, 10, 600, 1), (4, 'Wood', 'm3', 15000, 10, 2, 18000, 3), (5, 'Steel', 'ton', 60000, 5, 1, 72000, 4), (6, 'Tile', 'm2', 1200, 200, 30, 1440, 2), (7, 'Paint', 'can', 2000, 80, 15, 2400, 3), (8, 'Glass', 'm2', 1500, 150, 20, 1800, 4), (9, 'Glue', 'kg', 400, 250, 40, 480, 3), (10, 'Nails', 'kg', 100, 1000, 100, 120, 2), (11, 'Roof', 'm2', 3000, 60, 10, 3600, 4), (12, 'Pipe', 'm', 500, 300, 50, 600, 1);
```

### 2. ИМПОРТ (ОТГРУЗКИ)
1. ПКМ по таблице `shipments` -> **Table Data Import Wizard**.
2. Выбери файл `TICKET5_DATA.csv`.
3. **МАППИНГ:**
   - `k_mat` -> `id_mat`
   - `k_klient` -> `id_klient`
   - `k_man` -> `id_man`
   - `data_otgr` -> `data_otgr`
   - `v_otgr` -> `v_otgr`
   - **ВАЖНО:** Если в правой колонке `Dest Column` стоит `(none)` или что-то лишнее — очисти это поле (выбери пустую строку).
4. Жми Next до конца.

### 3. ПЛАН "Б" (РУЧНОЙ ВВОД)
**Что делать:** Если импорт не сработал. Тут 36 записей.
```sql
USE build_mat;
INSERT INTO shipments (id_mat, id_klient, id_man, data_otgr, v_otgr) VALUES 
(1,1,1,'2024-11-01',10), (2,2,2,'2024-11-02',50), (3,3,3,'2024-11-03',5), (4,4,1,'2024-11-04',2), (5,5,2,'2024-11-05',1), (6,6,3,'2024-11-06',20),
(7,1,1,'2024-11-07',15), (8,2,2,'2024-11-08',12), (9,3,3,'2024-11-09',100), (10,4,1,'2024-11-10',300), (11,5,2,'2024-11-11',25), (12,6,3,'2024-11-12',8),
(1,2,1,'2024-11-13',5), (2,3,2,'2024-11-14',200), (3,4,3,'2024-11-15',10), (4,5,1,'2024-11-16',3), (5,6,2,'2024-11-17',1), (6,1,3,'2024-11-18',40),
(7,2,1,'2024-11-19',10), (8,3,2,'2024-11-20',5), (9,4,3,'2024-11-21',50), (10,5,1,'2024-11-22',100), (11,6,2,'2024-11-23',10), (12,1,3,'2024-11-24',2),
(1,3,1,'2024-11-25',15), (2,4,2,'2024-11-26',500), (3,5,3,'2024-11-27',2), (4,6,1,'2024-11-28',1), (5,1,2,'2024-11-29',1), (6,2,3,'2024-11-30',5),
(7,3,1,'2024-12-01',20), (8,4,2,'2024-12-02',10), (9,5,3,'2024-12-03',30), (10,6,1,'2024-12-04',50), (11,1,2,'2024-12-05',5), (12,2,3,'2024-12-06',2);
```

**КАК ПРОВЕРИТЬ (ПОКАЗАТЬ ПРЕПОДУ):**
```sql
SELECT COUNT(*) FROM materials; -- Должно быть 12+
SELECT COUNT(*) FROM shipments; -- Должно быть 30+
```

---

## 📊 ЗАДАНИЕ 3: ЗАПРОСЫ
**1. Отчет за квартал:**
```sql
SELECT c.n_klient, m.n_mat, s.v_otgr, (s.v_otgr * m.cena_otgr) as total, man.fio_man 
FROM shipments s JOIN clients c ON s.id_klient = c.id JOIN materials m ON s.id_mat = m.id JOIN managers man ON s.id_man = man.id 
WHERE QUARTER(s.data_otgr) = 4;
```
**2. Цена > средней по ед. измерения:**
```sql
SELECT n_mat FROM materials m1 WHERE cena_otgr > (SELECT AVG(cena_otgr) FROM materials m2 WHERE m1.ed_izm = m2.ed_izm);
```
**3. Остаток ниже минимального:**
```sql
SELECT n_mat, kol_sklad FROM materials WHERE kol_sklad < min_reserve;
```
**4. Скидка 5% от поставщика 1:**
```sql
UPDATE materials SET cena_post = cena_post * 0.95 WHERE id_post = 1;
```
**ВИЗУАЛЬНОЕ ДОКАЗАТЕЛЬСТВО (ПО ЗАПРОСАМ):**
1. **Запрос 1:** "Квартальный отчет по продажам. Использовал функцию `QUARTER()`, чтобы сгруппировать данные по периоду."
2. **Запрос 2:** "Анализ цен по категориям. Сравниваю цену материала со средней именно в его группе (кг к кг, тонны к тоннам)."
3. **Запрос 3:** "Складской контроль: выборка товаров, уровень которых упал ниже критического резерва."
4. **Запрос 4:** "Массовое обновление цен поставщика при заключении спецконтракта."

---

## ⚡️ ЗАДАНИЕ 4: ТРИГГЕР (СКЛАД + РЕЗЕРВ)
```sql
DELIMITER //
CREATE TRIGGER tr_stock_ship BEFORE INSERT ON shipments FOR EACH ROW 
BEGIN 
  DECLARE cur_stock INT;
  SELECT kol_sklad INTO cur_stock FROM materials WHERE id = NEW.id_mat;
  IF cur_stock >= NEW.v_otgr THEN 
    UPDATE materials SET kol_sklad = kol_sklad - NEW.v_otgr WHERE id = NEW.id_mat; 
  ELSE 
    UPDATE materials SET reserve = reserve + NEW.v_otgr WHERE id = NEW.id_mat;
    INSERT INTO purchase_requests (id_mat, qty, date_req) VALUES (NEW.id_mat, NEW.v_otgr, CURDATE());
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Not enough stock! Check Reserve table.';
  END IF; 
END //
DELIMITER ;

**ВИЗУАЛЬНОЕ ДОКАЗАТЕЛЬСТВО (ДЛЯ ПРЕПОДА):**
1. Скажи: "Сейчас я попробую отгрузить клиенту кирпич (ID 2), которого на складе мало. Если товара не хватит, система создаст заявку на закупку."
2. Покажи остаток: `SELECT kol_sklad FROM materials WHERE id = 2;`
3. Попробуй отгрузить больше, чем есть: `INSERT INTO shipments (id_mat, id_klient, id_man, data_otgr, v_otgr) VALUES (2, 1, 1, CURDATE(), 99999);`
4. Покажи на сообщение об ошибке и новую запись в заявках: `SELECT * FROM purchase_requests;`
```

---

## 🛠 ЗАДАНИЕ 5: БЭКАП (Как в Билете 1)
